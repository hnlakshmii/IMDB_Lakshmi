package com.lakshmi1.movieapp.features.movies.ui

import com.lakshmi1.movieapp.features.movies.domain.model.MovieUiModel

data class MovieState(
    val data: List<MovieUiModel> = emptyList(),
    val error:String = "",
    val isLoading:Boolean = false
)
