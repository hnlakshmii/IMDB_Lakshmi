package com.lakshmi1.movieapp.features.movies.domain.model

import com.lakshmi1.movieapp.data.model.Movies

data class MovieUiModel(
    val results: Movies.Results
)
