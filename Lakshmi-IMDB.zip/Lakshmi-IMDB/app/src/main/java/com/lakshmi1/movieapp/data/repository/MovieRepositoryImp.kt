package com.lakshmi1.movieapp.data.repository

import com.lakshmi1.movieapp.common.Result
import com.lakshmi1.movieapp.common.base.BaseRepository
import com.lakshmi1.movieapp.data.model.Movies
import com.lakshmi1.movieapp.data.network.ApiService
import com.lakshmi1.movieapp.features.movies.domain.repository.MovieRepository
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

class MovieRepositoryImp @Inject constructor(
    private val apiService: ApiService,
) : BaseRepository() , MovieRepository {

    override suspend fun getMovies(): Flow<Result<Movies>> = safeApiCall {
        apiService.getMoviesList()
    }
}