package com.lakshmi1.movieapp.utils

sealed class MovieNavigationItems(val route:String){

    object MovieList : MovieNavigationItems("movielist")
    object MovieDetails : MovieNavigationItems("movieDetails")

}
