package com.lakshmi1.movieapp.common.base

interface Mapper<F,T> {

    fun mapFrom(from:F):T

}