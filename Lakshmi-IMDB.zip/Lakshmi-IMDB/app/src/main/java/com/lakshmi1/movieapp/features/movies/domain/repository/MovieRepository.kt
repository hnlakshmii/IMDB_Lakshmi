package com.lakshmi1.movieapp.features.movies.domain.repository

import com.lakshmi1.movieapp.common.Result
import com.lakshmi1.movieapp.data.model.Movies
import kotlinx.coroutines.flow.Flow

interface MovieRepository {

    suspend fun getMovies():Flow<Result<Movies>>

}