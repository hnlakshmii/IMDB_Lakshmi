package com.lakshmi1.movieapp.data.network

import com.lakshmi1.movieapp.data.model.Movies
import retrofit2.Response
import retrofit2.http.GET

interface ApiService {

    companion object {
        const val BASE_URL = "https://api.themoviedb.org/"
        const val BASE_POSTER_URL = "https://image.tmdb.org/t/p/w500/"
    }

    @GET("3/discover/movie?api_key=38a73d59546aa378980a88b645f487fc")
    suspend fun getMoviesList(): Response<Movies>
}